class Image < ApplicationRecord
    
    belongs_to :course
end
