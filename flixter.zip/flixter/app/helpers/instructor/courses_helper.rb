module Instructor::CoursesHelper
end
