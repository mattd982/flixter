class StaticPagesController < ApplicationController

  def index
  end
  
  def privacy
  end

end